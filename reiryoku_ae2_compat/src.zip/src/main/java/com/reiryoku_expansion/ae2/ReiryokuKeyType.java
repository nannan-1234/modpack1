package com.reiryoku_expansion.ae2;

import com.reiryoku_expansion.ReiryokuElement;

import appeng.api.stacks.AEKey;
import appeng.api.stacks.AEKeyType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/**
 * The Reiryoku key type: 1 byte stores 1 Reiryoku, and each import/export bus
 * operation moves exactly 1 Reiryoku (acceleration cards multiply the number
 * of operations per work cycle through AE2's normal upgrade logic).
 */
public final class ReiryokuKeyType extends AEKeyType {

    public static final ReiryokuKeyType INSTANCE = new ReiryokuKeyType();

    private ReiryokuKeyType() {
        super(new ResourceLocation("reiryoku_expansion", "reiryoku"),
                ReiryokuKey.class,
                Component.m_237115_("key.reiryoku_expansion.reiryoku")); // translatable
    }

    @Override
    public AEKey readFromPacket(FriendlyByteBuf buffer) {
        ReiryokuElement element = ReiryokuElement.byOrdinal(buffer.m_130242_()); // readVarInt
        return element == null ? null : ReiryokuKey.of(element);
    }

    @Override
    public AEKey loadKeyFromTag(CompoundTag tag) {
        ReiryokuElement element = ReiryokuElement.byOrdinal(tag.m_128451_("e")); // getInt
        return element == null ? null : ReiryokuKey.of(element);
    }

    @Override
    public int getAmountPerOperation() {
        return 1;
    }

    @Override
    public int getAmountPerByte() {
        return 1;
    }

    @Override
    public String getUnitSymbol() {
        return "RY";
    }
}
