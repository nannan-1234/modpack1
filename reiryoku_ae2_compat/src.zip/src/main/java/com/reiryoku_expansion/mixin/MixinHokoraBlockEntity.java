package com.reiryoku_expansion.mixin;

import com.iwaliner.urushi.blockentity.HokoraBlockEntity;
import com.iwaliner.urushi.util.ElementType;
import com.reiryoku_expansion.hokora.HokoraFuelConfig;

import net.minecraft.core.BlockPos;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Makes the Hokora (神龛) item → Reiryoku conversion data-driven instead of
 * hardcoded. The fuel item, the amount per conversion and the cooldown are
 * configured through {@code data/<namespace>/reiryoku_hokora/*.json} and can
 * be changed with {@code /reload}.
 *
 * <p>All three target methods belong to Urushi (not obfuscated), so the
 * injections use {@code remap = false} and no refmap is needed.</p>
 */
@Mixin(HokoraBlockEntity.class)
public abstract class MixinHokoraBlockEntity {

    @Inject(method = "getFuel", at = @At("HEAD"), cancellable = true, remap = false)
    private static void reiryokuexpansion$configuredFuel(ElementType element, CallbackInfoReturnable<Item> cir) {
        Item item = HokoraFuelConfig.getFuel(element);
        if (item != null) {
            cir.setReturnValue(item);
        }
    }

    @Inject(method = "getAddAmount", at = @At("HEAD"), cancellable = true, remap = false)
    private void reiryokuexpansion$configuredAmount(CallbackInfoReturnable<Integer> cir) {
        ElementType element = ((HokoraBlockEntity) (Object) this).getStoredElementType();
        Integer amount = HokoraFuelConfig.getReiryokuAmount(element);
        if (amount != null) {
            cir.setReturnValue(amount);
        }
    }

    /**
     * Replaces the hardcoded 100-tick cooldown in {@code tick}. The handler
     * receives the original constant plus the static tick method's arguments,
     * so it can look up the config for the ticking hokora's element.
     */
    @ModifyConstant(method = "tick", constant = @Constant(intValue = 100), remap = false)
    private static int reiryokuexpansion$configuredCooldown(int original, Level level, BlockPos pos, BlockState state,
                                                      HokoraBlockEntity hokora) {
        Integer cooldown = HokoraFuelConfig.getCooldown(hokora.getStoredElementType());
        return cooldown == null ? original : cooldown;
    }
}
